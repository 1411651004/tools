/*
* @Author: Rosen
* @Date:   2017-05-26 18:19:14
* @Last Modified by:   Rosen
* @Last Modified time: 2017-05-26 18:20:00
*/

'use strict';

require('./index.css');
require('./unslider.js');